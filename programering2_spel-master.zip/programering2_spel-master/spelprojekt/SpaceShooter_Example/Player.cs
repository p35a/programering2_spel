﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace SpaceShooter_Example
{
    class Player : PhysicalObject
    {
        public int Points { get; set; } = 0;
        double force = 0;
        enum controllerState { none, right, left, both }
        controllerState cState = controllerState.none;
        public Vector2 Origin;

        Texture2D textureNone;
        Texture2D textureRight;
        Texture2D textureleft;
        Texture2D textureBoth;

        public Player(Texture2D textureNone, Texture2D textureRight, Texture2D textureleft, Texture2D textureBoth, float X, float Y, double mass, double direction) : base(textureNone, X, Y, mass, direction)
        {
            this.textureNone = textureNone;
            this.textureRight = textureRight;
            this.textureleft = textureleft;
            this.textureBoth = textureBoth;
        }
        
        //UPDATE

        public void uppdate(GameWindow Window, GameTime gameTime)
        {
            KeyboardState keyBoardState = Keyboard.GetState();

            if (vector.Y <= Window.ClientBounds.Height - texture.Height && vector.Y >= 0 && vector.X <= Window.ClientBounds.Width - texture.Width && vector.X >= 0)
            {
                if (keyBoardState.IsKeyDown(Keys.Up) || keyBoardState.IsKeyDown(Keys.Left) && keyBoardState.IsKeyDown(Keys.Right))
                {
                    force = 1000;
                    cState = controllerState.both;
                }
                else if (keyBoardState.IsKeyDown(Keys.Right))
                {
                    force = 800;
                    direction += 0.01;
                    cState = controllerState.right;
                }
                else if (keyBoardState.IsKeyDown(Keys.Left))
                {
                    force = 800;
                    direction -= 0.01;
                    cState = controllerState.left;
                }
                else
                {
                    force = 0;
                    cState = controllerState.none;
                }
            }
            else
            {
                IsAlive = false;
            }

            if (keyBoardState.IsKeyDown(Keys.Escape))
            {
                IsAlive = false;
            }

            Acceleration(Window, force, direction);
        }

        //DRAW

        public override void Draw(SpriteBatch spriteBatch)
        {
            if(cState == controllerState.both)
            {
                spriteBatch.Draw(textureBoth, vector, null, null, Origin, (float)direction * -1, null, Color.White, SpriteEffects.None, 0f);
            }
            else if(cState == controllerState.left)
            {
                spriteBatch.Draw(textureleft, vector, null, null, Origin, (float)direction * -1, null, Color.White, SpriteEffects.None, 0f);
            }
            else if(cState == controllerState.right)
            {
                spriteBatch.Draw(textureRight, vector, null, null, Origin, (float)direction* -1, null, Color.White, SpriteEffects.None, 0f);
            }
            else
            {
                spriteBatch.Draw(textureNone, vector, null, null, Origin, (float)direction * -1, null, Color.White, SpriteEffects.None, 0f);
            }
        }

        //RESET

        public void Reset(GameWindow Window)
        {
            vector.X = 380;
            vector.Y = Window.ClientBounds.Bottom - 1000;
            speed.X = 0;
            speed.Y = 0;

            Points = 0;
            IsAlive = true;
        }
    }
}
